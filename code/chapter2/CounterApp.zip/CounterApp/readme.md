# Ionic 2 Counter App
Ionic 2 Counter App which has two buttons one to increment a counter another to reset the counter

## Pre-requisites

### Node.js

Latest version of Node.js 

### Ionic 2

Latest version of Ionic would install Ionic 2.  Also install the plugin 

## Running the app

* Download the code
* Issue the command "npm install"
* Issue "ionic serve" to run on the browser

## Running the app in android mobile

* Issue "ionic platform add android"
* Issue "ionic build android"
* To run the app on the android emulator run "ionic emulate android"
* To run the app on the connected device run "ionic run android"

## Running the app in iOS mobile

* Issue "ionic platform add ios"
* Issue "ionic build ios"
* To run the app on the iOS simulator run "ionic emulate android"
* To run the app on the connected device run "ionic run ios"

